# QOLMod

A free mod menu for [Geode](https://geode-sdk.org) made by TheSillyDoggo with **a user friendly interface** and **over 70 features** to help improve your Geometry Dash experience such as **Speedhack, Show Hitboxes, StartPos Switcher, Solid Wave Trail** and **much** more!

If you have any issues with the mod, you can join our [Discord server](https://discord.gg/DfQSTEnQKK) for help!

# How to use

- On Windows and Mac, press **Tab**, **F12**, or **Insert** on your keyboard. These **can be changed in the mod menu's settings**.
- On Android, press the button on your screen to open the mod menu.
