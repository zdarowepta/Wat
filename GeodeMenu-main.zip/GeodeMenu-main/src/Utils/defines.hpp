#include <Geode/Geode.hpp>

#ifdef GEODE_IS_MACOS
#define GEODE_IS_APPLE
#endif

#ifdef GEODE_IS_IOS
#define GEODE_IS_APPLE
#endif