/*#pragma once

#include <Geode/Geode.hpp>
#include <Geode/modify/CCParticleSystem.hpp>
#include "../../Client/Client.h"

using namespace geode::prelude;

class $modify (SteppedParticleSystem, CCParticleSystem)
{
    bool shouldStepFrame();

    virtual void update(float dt);
};*/