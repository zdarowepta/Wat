#pragma once

#include <Geode/Geode.hpp>
#include "../Client/Client.h"

using namespace geode::prelude;

extern FMOD::ChannelGroup* masterGroup;